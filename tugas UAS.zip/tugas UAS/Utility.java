// e. Manipulasi String & Date
import java.text.SimpleDateFormat;
import java.util.Date;

class Utility {
    public static void printReceipt(String customerName) {
        String upperName = customerName.toUpperCase();
        String date = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());
        System.out.println("Receipt for: " + upperName);
        System.out.println("Date: " + date);
    }
}