// d. Perulangan, Percabangan, Perhitungan
class Transaction {
    private Product product;
    private int quantity;

    public Transaction(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public void processTransaction() {
        double total = product.calculatePrice(quantity);
        if (total > 500000) {
            System.out.println("Diskon 10% diterapkan!");
            total *= 0.9;
        }
        System.out.println("Total harga: Rp " + total);
    }
}