// g. Collection Framework
import java.util.ArrayList;

class Inventory {
    private ArrayList<Product> products = new ArrayList<>();

    public void addProduct(Product p) {
        products.add(p);
    }

    public void showProducts() {
        for (Product p : products) {
            System.out.println(p.name + " - Rp " + p.price);
        }
    }
}
