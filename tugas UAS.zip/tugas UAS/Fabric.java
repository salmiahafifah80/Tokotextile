// c. Inheritance (superclass & subclass)
class Fabric extends Product {
    private double lengthPerMeter;

    public Fabric(String name, double price, double lengthPerMeter) {
        super(name, price);
        this.lengthPerMeter = lengthPerMeter;
    }

    @Override
    public double calculatePrice(int meters) {
        return price * meters;
    }
}

class Accessory extends Product {
    public Accessory(String name, double price) {
        super(name, price);
    }
}