// h. JDBC & CRUD (contoh sederhana)
import java.sql.*;

class FabricDB implements CRUDOperations   {
    private Connection conn;

    public FabricDB() {
    try {
        conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/tokokain?useSSL=false&serverTimezone=UTC",
            "root",
            ""
        );
        System.out.println("Koneksi berhasil!");
    } catch (SQLException e) {
        System.out.println("Gagal koneksi ke database!");
        e.printStackTrace();
    }
}
    @Override
    public void create() {
        try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("INSERT INTO fabric(name, price) VALUES('Katun', 50000)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void read() {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM fabric");
            while (rs.next()) {
                System.out.println(rs.getString("name") + " - Rp " + rs.getDouble("price"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update() {
        try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("UPDATE fabric SET price=60000 WHERE name='Katun'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete() {
        try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("DELETE FROM fabric WHERE name='Katun'");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
}
